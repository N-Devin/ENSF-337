//
// Created by Nimna Wijedasa on 11/24/22.
//
#include <iostream>
#include <cstdlib>
using namespace std;
#include "list.h"

FlowList::FlowList(): headM(0)
{

}

FlowList::FlowList(const FlowList& source)
{
    copy(source);
}

FlowList& FlowList::operator =(const FlowList& rhs)
{
    if (this != &rhs) {
        destroy();
        copy(rhs);
    }
    return *this;
}

FlowList::~FlowList() {
    destroy();
}


void FlowList::copy(const FlowList& source)
{
    if(source.headM == nullptr){
        headM = nullptr;
        return;
    }
    headM = new Node;
    Node *temp_node = headM;
    const Node *source_node = source.headM;
    while(true){
        temp_node-> item = source_node-> item;
        source_node = source_node -> next;
        if( source_node == nullptr ){
            break;
        }
        temp_node->next = new Node;
        temp_node = temp_node->next;
    }
    temp_node->next = nullptr;

}

void FlowList::destroy()
{
    while(headM){
        Node *to_be_destroyed = headM;
        headM = headM->next;
        delete to_be_destroyed;
    }
    headM = nullptr;
}

void FlowList::insert(const ListItem& itemA)
{
    Node *new_node = new Node;
    new_node->item = itemA;

    if (headM == 0 || itemA.flow <= headM->item.flow && itemA.year <= headM->item.year ) {
        new_node->next = headM;
        headM = new_node;
        // point one
    }
    else {
        Node *before = headM;      // will point to node in front of new node
        Node *after = headM->next; // will be 0 or point to node after new node
        while(after != nullptr && itemA.flow > after->item.flow && itemA.year > after->item.year) {
            before = after;
            after = after->next;
        }
        new_node->next = after;
        before->next = new_node;
        // point two
    }
}


void FlowList::remove(const string& year)
{
    // if list is empty, do nothing
    if (headM == nullptr || (stoi(year) < headM->item.year))
        return;

    Node *doomed_node = nullptr;

    if (stoi(year) == headM->item.year) {
        doomed_node = headM;
        headM = headM->next;
    }
    else {
        Node *before = headM;
        Node *maybe_doomed = headM->next;
        while(maybe_doomed != nullptr && stoi(year) > maybe_doomed->item.year) {
            before = maybe_doomed;
            maybe_doomed = maybe_doomed->next;
        }
        // point three
        before->next=maybe_doomed->next;
    }
    delete doomed_node;
}

double FlowList::average(){
    int values= 0;
    double sum = 0;
    double average;

    while (headM != nullptr) {
        sum += headM->item.flow;
        values+= 1;
        headM = headM->next;
    }
    average = sum / values;
    return average;
};

void FlowList::print() const
{
    cout << "Year\tFlow"
    <<endl;
    if (headM != nullptr) {
        cout << headM->item.year << '\t' << headM->item.flow;
        for (const Node *p = headM->next; p != nullptr; p = p->next)
            cout << "\n"
            << p->item.year
            << '\t'
            << p->item.flow;
    }
}

void FlowList::save(const string& file_name){
    Node *cursor_val = headM;
    ofstream outObj;
    outObj.open(file_name);
    while (cursor_val){
        outObj << cursor_val->item.year << '\t' << cursor_val->item.year
        << endl;
        cursor_val = cursor_val->next;
    }
    outObj.close();
}
