//
// Created by Nimna Wijedasa on 11/24/22.
//

#ifndef LAB8_LIST_H
#define LAB8_LIST_H
#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace ::std;

struct ListItem {
    int year;
    double flow;
};

struct Node {
    ListItem item;
    Node *next;
};

class FlowList {
public:
    FlowList();
    FlowList(const FlowList& source);
    FlowList& operator =(const FlowList& rhs);
    ~FlowList();

    void insert(const ListItem& itemA);
    void remove(const string& year);
    double average();
    void print() const;
    void save(const string& file_name);

private:
    Node *headM{};
    void destroy();
    void copy(const FlowList& source);

};

#endif //LAB8_LIST_H
