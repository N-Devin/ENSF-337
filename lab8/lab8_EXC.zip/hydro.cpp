//
// Created by Nimna Wijedasa on 11/24/22.
//
#include <iostream>
#include <fstream>
#include "hydro.h"
#include "list.h"
using namespace ::std;
int main() {
    FlowList x;
    FlowList *point_list = nullptr;
    int numRecords;
    displayHeader();

    string myText;
    string file_name = "flow.txt";
    ifstream MyReadFile(file_name);

    // Make sure if file was opened successfully
    if (!MyReadFile)  {
        cout << "Error: cannot open the file" << endl;
        exit(1);
    }
    string s;
    int records = 0;
    while(!MyReadFile.eof()){
        getline(MyReadFile, s);
        records++;
    }
    int *rec_ptr = &records;
    MyReadFile.clear();
    MyReadFile.seekg(0, ios::beg);
    while(!MyReadFile.eof()){
        int year;
        double flow;
        ListItem insertItem{};

        MyReadFile >> insertItem.year >> insertItem.flow;
        point_list->insert(insertItem);
        getline(MyReadFile, s);
    }

    //numRecords = readData(x);
    int quit = 0;
    while (true) {
        switch (menu()) {
            case 1:
                // call display function;
                display( x);
                cout<<"hit enter to continue";
                press_enter();
                break;
            case 2:
                // call addData function
                addData(x,rec_ptr);
                press_enter();
                break;
            case 3:
                // call saveData function;
                commit_local(file_name, x);
                cout<<"hit enter to continue";
                press_enter();
                break;
            case 4:
                cout << "\n4!\n\n";
                // call removeData
                removeData(x, rec_ptr);

                // call presenter;
                break;
            case 5:
                cout << "\nProgram terminated!\n\n";
                quit = 1;
                break;
            default:
                cout << "\nNot a valid input.\n";

        }
        if (quit == 1) break;

    }
    MyReadFile.close();
}

void press_enter()
{
    string myString;
    do {
        getline(std::cin, myString);
    } while (myString.length() != 0);
}
void displayHeader()
{
    string myString;
    cout<<"Program: Flow Studies, Fall 2022\n"
        <<"Version: 1.0\n"
        <<"Lab section: 02\n"
        <<"Produced by: Nimna Wijedasa\n"
        <<"<<< Press Enter to Continue>>>>\n";
    press_enter();
};
int menu()
{
    int num = 0;
    cout<<"Please select on the following operations\n"
        <<"1. Display flow list, and the average.\n"
        <<"2. Add data.\n"
        <<"3. Save data into the file\n"
        <<"4. Remove data\n"
        <<"5. Quit\n"
        <<"Enter your choice (1, 2, 3, 4, of 5):\n";
    cin >> num;
    return num;
};

void display(const FlowList& list){
    list.print();
    cout << "\nThe annual average of the flow is: " << average(list) << " billions cubic metres\n";
}

double average(FlowList list){
    return list.average();
}

void addData(FlowList list, const int *records){
    ListItem newItem{};
    cout<<"\nYear: ";
    cin>>newItem.year;
    cout<<"\nFlow: ";
    cin>>newItem.flow;

    list.insert(newItem);
    press_enter();
    records += 1;
}

void commit_local(const string& file_name, FlowList list){
    list.save(file_name);
}

void removeData(FlowList list, const int *records){
    string year;
    cout<<"\nYear: ";
    cin>>year;

    list.remove(year);
    press_enter();
    records -= 1;
}