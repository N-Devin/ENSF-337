//
// Created by Nimna Wijedasa on 11/24/22.
//
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <string>
#include "list.h"
using namespace ::std;
#ifndef LAB8_HYDRO_H
#define LAB8_HYDRO_H

void press_enter();
void displayHeader();
int menu();

void display(const FlowList& list);
double average(FlowList list);
void addData(FlowList list, const int *records);
void commit_local(const string& file_name, FlowList list);
void removeData(FlowList list, const int *records);



//readData(char *x)




#endif //LAB8_HYDRO_H
